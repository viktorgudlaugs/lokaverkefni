$.ajax({
  url: "https://apis.is/tv/ruv",
  type: "GET",
  dataType: "json",
  success: function(response){
    for(var i=0;i<response.results.length;i++){
      var current=response.results[i];
      console.log(current);
      $(".p").append('<div><div class="col-md-4 col-xs-4 col-sm-4"><p class="p2">'+current.startTime+':</p></div><div class="col-md-4 col-xs-4 col-sm-4"><p class="p2">'+current.title+'</p></div><div class="col-md-4 col-xs-4 col-sm-4"><p class="p2">'+current.duration+'</p></div>');
    }
  }
});